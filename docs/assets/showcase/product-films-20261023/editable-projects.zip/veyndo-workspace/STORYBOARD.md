# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–10s | w-start | ui | Start with the work that matters to your shop. |
| 10–22s | w-catalogue | ui | Start from a CSV, describe the products you need, or provide a source URL. |
| 22–34s | w-agent | ui | An agent can prepare related catalogue and content changes as one task. |
| 34–46s | w-design | ui | Shape the standard storefront directly in its visual preview. |
| 46–58s | w-discovery | ui | Shoppers can describe what they need and compare actual products. |
| 58–72s | w-b2b | ui | Combine app-owned materials, custom dimensions and surcharges with company purchasing. |
| 72–86s | w-simulate | ui | Preview fictional customer profiles based on the selected catalogue and channel. |
| 86–96s | w-close | ui | From catalogue preparation to storefront design, purchasing and scenario testing. |
