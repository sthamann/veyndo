# Director specification

GOAL: Follow the connected catalogue, agent, design, shopping, B2B and scenario journey.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 96 seconds × 30 = 2880 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–10s | w-start | ui | Start with the work that matters to your shop. |
| 10–22s | w-catalogue | ui | Start from a CSV, describe the products you need, or provide a source URL. |
| 22–34s | w-agent | ui | An agent can prepare related catalogue and content changes as one task. |
| 34–46s | w-design | ui | Shape the standard storefront directly in its visual preview. |
| 46–58s | w-discovery | ui | Shoppers can describe what they need and compare actual products. |
| 58–72s | w-b2b | ui | Combine app-owned materials, custom dimensions and surcharges with company purchasing. |
| 72–86s | w-simulate | ui | Preview fictional customer profiles based on the selected catalogue and channel. |
| 86–96s | w-close | ui | From catalogue preparation to storefront design, purchasing and scenario testing. |
