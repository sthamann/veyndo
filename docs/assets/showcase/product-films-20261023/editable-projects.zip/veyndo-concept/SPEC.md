# Director specification

GOAL: Understand why Veyndo exists and how AI, native commerce and apps connect.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 72 seconds × 30 = 2160 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–10s | c-outcome | ui | What if your shop could help you do the work? |
| 10–22s | c-goal | ui | Describe the result you want. The agent uses your catalogue and current context. |
| 22–36s | c-core | diagram | The storefront, apps and agents use the same native Rust commerce operations. |
| 36–50s | c-experience | ui | Storyfront creates the shopping experience. Veyndo supplies the catalogue, cart and checkout. |
| 50–62s | c-control | ui | Explore changes in a private sandbox before they reach your live shop. |
| 62–72s | c-close | ui | One platform for merchant work, shopping experiences and new capabilities. |
