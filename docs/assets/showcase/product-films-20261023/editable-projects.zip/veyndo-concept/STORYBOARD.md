# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–10s | c-outcome | ui | What if your shop could help you do the work? |
| 10–22s | c-goal | ui | Describe the result you want. The agent uses your catalogue and current context. |
| 22–36s | c-core | diagram | The storefront, apps and agents use the same native Rust commerce operations. |
| 36–50s | c-experience | ui | Storyfront creates the shopping experience. Veyndo supplies the catalogue, cart and checkout. |
| 50–62s | c-control | ui | Explore changes in a private sandbox before they reach your live shop. |
| 62–72s | c-close | ui | One platform for merchant work, shopping experiences and new capabilities. |
