# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–10s | a-need | ui | When your business needs a new capability, build it as a connected app. |
| 10–22s | a-design | ui | The visual designer and coding agent work on the same versioned app definition. |
| 22–34s | a-data | diagram | Define app-owned records, relationships and the settings an installation needs. |
| 34–46s | a-flow | ui | Connect app actions to native events and the existing Flow Builder. |
| 46–58s | a-context | ui | Use Veyndo AI, or bring Codex or Claude Code into the same app workflow. |
| 58–72s | a-version | diagram | Save immutable app versions and test installed behaviour in a private environment. |
| 72–84s | a-close | ui | Apps extend the shop through shared commerce, permissions, events and releases. |
