# Director specification

GOAL: Explain visual and agent-assisted apps, data ownership, settings, events and controlled versions.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 84 seconds × 30 = 2520 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–10s | a-need | ui | When your business needs a new capability, build it as a connected app. |
| 10–22s | a-design | ui | The visual designer and coding agent work on the same versioned app definition. |
| 22–34s | a-data | diagram | Define app-owned records, relationships and the settings an installation needs. |
| 34–46s | a-flow | ui | Connect app actions to native events and the existing Flow Builder. |
| 46–58s | a-context | ui | Use Veyndo AI, or bring Codex or Claude Code into the same app workflow. |
| 58–72s | a-version | diagram | Save immutable app versions and test installed behaviour in a private environment. |
| 72–84s | a-close | ui | Apps extend the shop through shared commerce, permissions, events and releases. |
