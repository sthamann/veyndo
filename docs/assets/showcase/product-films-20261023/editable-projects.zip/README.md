# Veyndo product films — editable source

Three independent HyperFrames 0.8.186 projects. English, silent, 1920×1080 at 30fps. In a project directory run `npm run check`, `npx hyperframes@0.8.186 preview --background`, or `npm run render -- --quality delivery`. Node.js and FFmpeg are required; the first CLI/font installation requires network access. The individual files remain editable in Studio. No service credentials or live customer data are included.

Original UI captures and the approved logo retain the Veyndo repository license. GSAP retains its upstream license header. See each asset ledger for capture provenance. Captured interfaces are mainly German; the editorial explanation and subtitle files are English.
