# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | c-product | actual UI | Products connect content, selling channels and customer journeys. |
| 12–24s | c-agent | actual UI | The merchant assistant works with the current shop context. |
| 24–36s | c-work | actual UI | An agent can assemble a working view from native components. |
| 36–48s | c-app | actual UI | An installed consultation app retains its product request and private file. |
| 48–60s | c-design | actual UI | Design on the real storefront preview with graphical elements. |
| 60–72s | c-close | brand | Explore the current product and try the connected workflows. |
