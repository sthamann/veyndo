# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | a-start | actual UI | Start with the merchant task and the information the app needs. |
| 12–24s | a-design | actual UI | Arrange graphical components and select their properties. |
| 24–36s | a-agent | actual UI | Open the app assistant beside the current work. |
| 36–48s | a-settings | actual UI | Declare the settings a merchant fills after installing the app. |
| 48–60s | a-record | actual UI | The installed app contains a saved consultation request. |
| 60–72s | a-upgrade | actual UI | An upgrade is checked against existing app records and active consumers. |
| 72–84s | a-close | brand | Explore the current product and try the connected workflows. |
