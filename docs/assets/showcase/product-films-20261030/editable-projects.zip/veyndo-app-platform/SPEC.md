# Director specification

GOAL: Follow one consultation app from the creation entry to its actual stored request.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 84 seconds × 30 = 2520 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of actual still captures, never a real-time recording claim. All current UI scenes were captured 29–30 October; the original source ledger identifies any older retained assets, which these four films do not use.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | a-start | actual UI | Start with the merchant task and the information the app needs. |
| 12–24s | a-design | actual UI | Arrange graphical components and select their properties. |
| 24–36s | a-agent | actual UI | Open the app assistant beside the current work. |
| 36–48s | a-settings | actual UI | Declare the settings a merchant fills after installing the app. |
| 48–60s | a-record | actual UI | The installed app contains a saved consultation request. |
| 60–72s | a-upgrade | actual UI | An upgrade is checked against existing app records and active consumers. |
| 72–84s | a-close | brand | Explore the current product and try the connected workflows. |
