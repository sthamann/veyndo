# Director specification

GOAL: Explain contextual agents through existing merchant, design, app and simulator workflows.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 116 seconds × 30 = 3480 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of actual still captures, never a real-time recording claim. All current UI scenes were captured 29–30 October; the original source ledger identifies any older retained assets, which these four films do not use.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–14s | i-work | actual UI | A merchant goal opens a working view with the actual catalogue. |
| 14–28s | i-context | actual UI | Shop intelligence brings catalogue knowledge and source management together. |
| 28–42s | i-catalogue | actual UI | Upload a CSV, provide a product URL, or describe sample products. |
| 42–56s | i-reference | actual UI | Add shop URLs, screenshots or design references in the shop editor. |
| 56–70s | i-proposal | actual UI | Inspect the prepared design in the same visual storefront editor. |
| 70–84s | i-app | actual UI | App creation and visual editing share native app data and actions. |
| 84–98s | i-buyers | actual UI | Fictional customer agents try native search, baskets and simulated checkout. |
| 98–116s | i-close | brand | Explore the current product and try the connected workflows. |
