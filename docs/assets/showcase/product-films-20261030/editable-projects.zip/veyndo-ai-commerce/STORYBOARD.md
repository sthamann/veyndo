# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–14s | i-work | actual UI | A merchant goal opens a working view with the actual catalogue. |
| 14–28s | i-context | actual UI | Shop intelligence brings catalogue knowledge and source management together. |
| 28–42s | i-catalogue | actual UI | Upload a CSV, provide a product URL, or describe sample products. |
| 42–56s | i-reference | actual UI | Add shop URLs, screenshots or design references in the shop editor. |
| 56–70s | i-proposal | actual UI | Inspect the prepared design in the same visual storefront editor. |
| 70–84s | i-app | actual UI | App creation and visual editing share native app data and actions. |
| 84–98s | i-buyers | actual UI | Fictional customer agents try native search, baskets and simulated checkout. |
| 98–116s | i-close | brand | Explore the current product and try the connected workflows. |
