# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | w-content | actual UI | The compact product editor keeps the essential work close together. |
| 12–24s | w-gallery | actual UI | Order a product gallery visually and inspect the selected media. |
| 24–36s | w-seo | actual UI | SEO fields use product text and language inheritance as defaults. |
| 36–48s | w-recommend | actual UI | Keep selected recommendations visible while searching the catalogue. |
| 48–60s | w-shop | actual UI | Related products use native pictures, contextual prices and product links. |
| 60–72s | w-design | actual UI | Drag graphical elements to the preview and rearrange sections. |
| 72–84s | w-test | actual UI | Reopen saved fictional customers and inspect their native steps. |
| 84–96s | w-close | brand | Explore the current product and try the connected workflows. |
