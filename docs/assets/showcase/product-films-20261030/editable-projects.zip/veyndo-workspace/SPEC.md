# Director specification

GOAL: Follow current product editing, visual design and saved customer-agent results.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 96 seconds × 30 = 2880 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of actual still captures, never a real-time recording claim. All current UI scenes were captured 29–30 October; the original source ledger identifies any older retained assets, which these four films do not use.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | w-content | actual UI | The compact product editor keeps the essential work close together. |
| 12–24s | w-gallery | actual UI | Order a product gallery visually and inspect the selected media. |
| 24–36s | w-seo | actual UI | SEO fields use product text and language inheritance as defaults. |
| 36–48s | w-recommend | actual UI | Keep selected recommendations visible while searching the catalogue. |
| 48–60s | w-shop | actual UI | Related products use native pictures, contextual prices and product links. |
| 60–72s | w-design | actual UI | Drag graphical elements to the preview and rearrange sections. |
| 72–84s | w-test | actual UI | Reopen saved fictional customers and inspect their native steps. |
| 84–96s | w-close | brand | Explore the current product and try the connected workflows. |
