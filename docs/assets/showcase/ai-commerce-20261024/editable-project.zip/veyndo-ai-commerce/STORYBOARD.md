# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–08s | ai-opening | ui | What if your shop understood what you wanted to achieve? |
| 08–20s | ai-context | ui | Ask from the product, order or workspace you are already using. |
| 20–32s | ai-catalogue | ui | Bring existing products or describe the demo catalogue you want to create. |
| 32–44s | ai-design | ui | Give the design agent a reference URL, screenshot or design brief. |
| 44–56s | ai-apps | ui | Create connected apps with visual tools and Veyndo AI, Codex or Claude Code. |
| 56–66s | ai-automation | ui | Connect native events, app actions and reviewed work in the Flow Builder. |
| 66–78s | ai-scenarios | ui | Generate fictional customer profiles from the selected catalogue and sales channel. |
| 78–88s | ai-shopping | ui | Customers describe what they need and explore real products, prices and availability. |
| 88–98s | ai-foundation | diagram | Agents, apps and storefronts use the same native commerce operations. |
| 98–108s | ai-control | ui | Prepare changes privately. Review the exact proposal before it reaches your live shop. |
| 108–116s | ai-close | ui | Start with a goal. Build, test and publish connected changes. |
