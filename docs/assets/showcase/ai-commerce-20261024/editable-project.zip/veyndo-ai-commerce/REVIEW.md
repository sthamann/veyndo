# Film review — 24 October 2026

- HyperFrames 0.8.186 runtime, layout and contrast checks passed. The silent soundtrack and dense English caption track are intentional.
- Inspected 72 composition frames including every scene, adjacent transitions and a phone preview; inspected eleven decoded MP4 frames and all ten transition pairs.
- Full ffmpeg decode passed. ffprobe confirms 3,480 frames, 116 seconds, 1920×1080, 30 fps, H.264 High Level 4.1, YUV420p and no audio stream. MP4 moov starts at byte 32, before mdat at 42,166.
- Native macOS Safari reproduced the old Team failure: native play had no source; chapter playback worked. With the repair, native play loaded this film, showed moving content at 11 seconds with duration 1:56, sought to 1:06, and paused when the second film started natively.
- Four player regressions cover native playback, failure recovery and metadata-dependent chapter seeking. Full private application checks: 252 tests passed plus typecheck, structure, four locales and production/team builds.
- Public handbook build/check: 324 pages and 34,188 local links/assets passed.
- This is a film/player check. Actual iPhone hardware and a new commerce transaction were not exercised.
