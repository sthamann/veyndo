# Director specification

GOAL: Explain the AI-first product through merchant work, extensible apps, customer scenarios and native commerce.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 116 seconds × 30 = 3480 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–08s | ai-opening | ui | What if your shop understood what you wanted to achieve? |
| 08–20s | ai-context | ui | Ask from the product, order or workspace you are already using. |
| 20–32s | ai-catalogue | ui | Bring existing products or describe the demo catalogue you want to create. |
| 32–44s | ai-design | ui | Give the design agent a reference URL, screenshot or design brief. |
| 44–56s | ai-apps | ui | Create connected apps with visual tools and Veyndo AI, Codex or Claude Code. |
| 56–66s | ai-automation | ui | Connect native events, app actions and reviewed work in the Flow Builder. |
| 66–78s | ai-scenarios | ui | Generate fictional customer profiles from the selected catalogue and sales channel. |
| 78–88s | ai-shopping | ui | Customers describe what they need and explore real products, prices and availability. |
| 88–98s | ai-foundation | diagram | Agents, apps and storefronts use the same native commerce operations. |
| 98–108s | ai-control | ui | Prepare changes privately. Review the exact proposal before it reaches your live shop. |
| 108–116s | ai-close | ui | Start with a goal. Build, test and publish connected changes. |
